<div class="span2 hp-wrapper">
	<a href="<?php print $fields['path']->content;?>">
		<img alt="" src="<?php print $fields['field_bebita_foto_pefil']->content;?>" />
	</a>
</div>