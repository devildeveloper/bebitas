<div id="clients" class="row show-grid">
	<?php print $rows ;?>
</div>