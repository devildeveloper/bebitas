<ul id="gallery" class="thumbnails">
    <?php print $rows ;?>
</ul>