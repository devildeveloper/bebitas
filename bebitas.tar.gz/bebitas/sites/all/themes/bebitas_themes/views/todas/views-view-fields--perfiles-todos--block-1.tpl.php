<li class="span3 small hp-wrapper mayor disponibles con-depa">                        
	<a href="<?php print $fields['path']->content ;?>">
		<img alt="" src="<?php print $fields['field_bebita_foto_pefil']->content ;?>" class="hover-shade" />
	</a>
    <a href="<?php print $fields['path']->content ;?>" class="top-link">
    	<img alt="" style="width: 220px; height: 160px;" src="<?php print $fields['field_bebita_foto_pefil']->content ;?>" />
    </a>
    <div class="bottom-block">
        <a href="<?php print $fields['path']->content ;?>"><?php print $fields['field_bebita_nombres']->content ;?></a>
        <div class="stado on"></div>
        <p><?php print $fields['field_bebita_ubicacion']->content ;?></p>
    </div>                                
</li>