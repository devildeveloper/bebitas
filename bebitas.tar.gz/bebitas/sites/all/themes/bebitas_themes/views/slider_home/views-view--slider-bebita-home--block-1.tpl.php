<div class="bannercontainer">
	<div class="banner">
		<ul>
			<?php print $rows ;?>
		</ul>
		<div class="tp-bannertimer"></div>
	</div>
</div>