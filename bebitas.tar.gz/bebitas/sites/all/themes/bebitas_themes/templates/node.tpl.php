  <?php  print $content; ?>

